AIR QUALITY DATA, downloaded from http://discomap.eea.europa.eu/map/fme/AirQualityExport.htm /19 Sept 2018/
IVAN PASPALDZHIEV - DENKSTATT BULGARIA - https://denkstatt.eu/?lang=bg - +359893336957

Contents of files:

Field						Type		Description
Countrycode					String		Country iso code
Namespace					String		Unique namespace as provided by the country
AirQualityNetwork			String		Network identifier
AirQualityStation			String		Localid of the station
AirQualityStationEoICode	String		Unique station identifier as used in the past AirBase system
Samplingpoint				String		Localid of the samplingpoint
Samplingpoint				String		Localid of the samplingpoint
SamplingProcess				String		Localid of the samplingprocess
Sample						String		Localid of the sample (also known as the feature of interest)
AirPollutant				String		Short name of pollutant. Full list: http://dd.eionet.europa.eu/vocabulary/aq/pollutant/view
AirPollutantCode			String		Reference (URL) to the definition of the pollutant in data dictonary
AveragingTime				String		Defines the time for which the measure have been taken (hour, day, etc)
Concentration				Value		The measured value/concentration
UnitOfMeasurement			String		Defines the unit of the concentration
DateTimeBegin				Datetime	Defines the start time (yyyy-mm-dd hh:mm:ss Z) of the measurement (includes timezone)
DateTimeEnd					Datetime	Defines the end time (yyyy-mm-dd hh:mm:ss Z)of the measurement (includes timezone		)
Validity					Integer		The validity flag for the measurement. See http://dd.eionet.europa.eu/vocabulary/aq/observationvalidity/view
Verification				Integer		The verification flag for the measurement. See http://dd.eionet.europa.eu/vocabulary/aq/observationverification/view

Metadata:

Field						Type		Description
Countrycode					String		Country iso code
Namespace					String		Namespace of network
AirQualityNetwork			String		Network identifier
AirQualityStation			String		Localid of station
AirQualityNatCode			String		National code of station
AirQualityStationEoICode	String		Station EoI code as used in the past AirBase system
AirQualityStationArea		String		Reference to area code. Full list at http://dd.eionet.europa.eu/vocabulary/aq/areaclassification/view
SamplingPoint				String		Localid of samplingpoint
SamplingProcess				String		Localid of process
Sample						String		Localid of sample (also known as feature of interest)
BuildingDistance			Integer		Distance to building (m). Value of -999 indicate unknown
EquivalenceDemonstrated		String		Reference to demonstrated equivalence. Full list at http://dd.eionet.europa.eu/vocabulary/aq/equivalencedemonstrated/view
InLetHeight					Integer		Height of inlet (m). Value of -999 indicate unknown
KerpDistance				Integer		Distance to kerp (m). Value of -999 indicate unknown
MeasurementEquipment		String		Refernce (URL) to measurement equipment
MeasurementType				String		Reference to measurement type (full list at http://dd.eionet.europa.eu/vocabulary/aq/measurementtype/view)
MeasurementMethod			String		Reference to measurement method (full list at http://dd.eionet.europa.eu/vocabulary/aq/measurementmethod/view)
AirPollutantCode			String		Reference (URL) to pollutant definition in data dictionary
AirPollutant				String		Short pollutant name measured at this samplingpoint
AirQualityStationType		String		Short name of station type (full list at http://dd.eionet.europa.eu/vocabulary/aq/stationclassification/view)
Projection					String		Reference to projection
Longitude					Decimal		Longitude of samplingpoint
Latitude					Decimal		Latitude of samplingpoint
Altitude					Integer		Altitude of samplingpoint (m)

Data have undergone QA and should be without error. In case of suspected inconsistencies, 
contact IVAN PASPALDZHIEV via contacts at the top of this document.