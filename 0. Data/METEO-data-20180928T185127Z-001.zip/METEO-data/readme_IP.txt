METEOROLOGICAL DATA, scraped from wunderground.com & NCDC /17.09.2018/
IVAN PASPALDZHIEV - DENKSTATT BULGARIA - https://denkstatt.eu/?lang=bg - +359893336957

SOFIA AIRPORT (LBSF)
WMO id: 15614 
Latitude:  42.6537 (decimal degree)
Longitude: 23.3829 (decimal degree)
Elevation: 595 metres (Google 592 metres; Google DEM not entirely accurate)

Data description

year		Year of measurement	
Month		Month of measurement	
day			Day of measurement	
TASMAX		Daily maximum temperature				degrees C
TASAVG		Daily average temperature				degrees C
TASMIN		Daily minimum temperature				degrees C
DPMAX		Daily maximum dew point temperature		degrees C
DPAVG		Daily average dew point temperature		degrees C
DPMIN		Daily minimum dew point temperature		degrees C
RHMAX		Daily maximum relative humidity			%
RHAVG		Daily average relative humidity			%
RHMIN		Daily minimum relative humidity			%
sfcWindMAX	Daily maximum wind speed				km/h
sfcWindAVG	Daily average wind speed				km/h
sfcWindMIN	Daily minimum wind speed				km/h
PSLMAX		Daily maximum surface pressure			hpa
PSLAVG		Daily average surface pressure			hpa
PSLMIN		Daily minimum surface pressure			hpa
PRCPMAX		Daily maximum precipitation amount		mm
PRCPAVG		Daily average precipitation amount		mm
PRCPMIN		Daily minimum precipitation amount		mm
VISIB		Daily average visibility				km

All data is measured at a standard 2-meter height. Pressure data is adjusted to sea-level.

MISSING VALUES = -9999

Data have undergone QA and should be without error. In case of suspected inconsistencies, 
contact IVAN PASPALDZHIEV via contacts at the top of this document.

********************************************************************